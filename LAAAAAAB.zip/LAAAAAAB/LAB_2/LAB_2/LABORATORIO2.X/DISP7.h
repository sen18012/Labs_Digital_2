/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef DISP7_H_
#define	DISP7_H_

#include <xc.h> // include processor files - each processor file is guarded.
#include <stdint.h>


uint8_t DISPLAY7(uint8_t val);


#endif	/* DISP7_H_*/
